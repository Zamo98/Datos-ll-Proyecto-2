var searchData=
[
  ['cantidadpoblacion_66',['cantidadPoblacion',['../algoritmo_genetico_8cpp.html#a7ecf9cc2911a8f0044c0aea0737c08f1',1,'algoritmoGenetico.cpp']]],
  ['columnas_67',['columnas',['../algoritmo_genetico_8cpp.html#aa92ff3faf741cefa932a3be3a1bf6e9d',1,'algoritmoGenetico.cpp']]]
];
