var searchData=
[
  ['borrarimagen_5',['borrarImagen',['../classcargar_imagen.html#ac3378727710a155a5b1e9e4389518b81',1,'cargarImagen']]]
];
