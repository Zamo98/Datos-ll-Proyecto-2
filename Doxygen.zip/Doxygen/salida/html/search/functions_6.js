var searchData=
[
  ['principal_64',['principal',['../classalgoritmo_genetico.html#a28c65d01c928bb937f370b7f444cd5f7',1,'algoritmoGenetico']]]
];
