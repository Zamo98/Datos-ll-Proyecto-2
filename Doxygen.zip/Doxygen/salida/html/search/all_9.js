var searchData=
[
  ['nuevosgenes_33',['nuevosGenes',['../algoritmo_genetico_8cpp.html#ad1085a4c2afbcf54124b800589588a55',1,'algoritmoGenetico.cpp']]]
];
