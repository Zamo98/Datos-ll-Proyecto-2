var searchData=
[
  ['longitudmat_27',['longitudMat',['../algoritmo_genetico_8cpp.html#a1cad15b74e50a6ee3b4b21830d00a926',1,'algoritmoGenetico.cpp']]]
];
